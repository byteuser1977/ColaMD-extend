import { createEditor, focusEditor, getMarkdown, getEditorView, getEditorScroller, onEditorJumpPhase, setMarkdown, setEditorEditable, getEditorState, restoreEditorState, applyMarkdownStyle, runFormatCommand, jumpToLine, jumpToHeading, setCleanExport, setDocumentFileUrl, setSourceMode, type FormatCommandId } from './editor/editor'
import { diagramPrintPalette, markdownForWord } from './editor/mermaid-export'
import { markdownWithMathImages } from './editor/math-export'
import { markdownWithHtmlImages } from './editor/html-export'
import { readDocxStyle } from './editor/docx-style'
import { withDiagramZoomPaused } from './editor/mermaid-bridge'
import { documentHTMLFrom } from './editor/clean-html'
import { isPresenting, startSlideshow, stopSlideshow } from './slideshow'
import { enterPrintLayout, exitPrintLayout } from './slides-export'
import { enterPaperLayout, exitPaperLayout } from './print-layout'
import { SearchPanel } from './editor/search-panel'
import { applyTheme, loadSavedTheme } from './themes/theme-manager'
import { setUiLanguage, isChinese, type UiLanguage } from './ui-language'
import { applyEditorFont, clearEditorFont, loadSavedEditorFont, resetEditorFontSize, showFontSettingsModal, stepEditorFontSize } from './editor/font-settings'
import './themes/base.css'
import './themes/premium.css'
import './themes/editor-preview.css'
import './themes/document.css'
import { installCapacitorAPI, isAndroidApp, startIntentPolling } from './capacitor-api'

// 移动端（Capacitor WebView）挂替身；Electron 桌面 no-op。必须在任何 electronAPI 触达之前。
installCapacitorAPI()
startIntentPolling()

// Android 顶栏：没有系统菜单栏，菜单按钮常显（点开 HTML 菜单浮层）；手机宽度放不下
// 文件列表开关，那个按钮不显示。放在模块顶部同步执行，不依赖 init 的异步流程。
if (isAndroidApp()) {
  document.body.classList.add('platform-android')
  document.getElementById('app-menu-btn')?.removeAttribute('hidden')
  const fileToggleBtn = document.getElementById('file-toggle-btn')
  if (fileToggleBtn) fileToggleBtn.hidden = true
}

let sourceModeActive = false
const editorEl = () => document.getElementById('editor') as HTMLElement
// 正文的滚动在 .cm-scroller 上，不在 #editor 上；见 editor.ts 的 getEditorScroller。
const editorScroller = () => getEditorScroller() ?? editorEl()
const filePanelEl = () => document.getElementById('file-panel') as HTMLElement
const fileListEl = () => document.getElementById('file-list') as HTMLElement
const outlineListEl = () => document.getElementById('outline-list') as HTMLElement
const fileTabEl = () => document.getElementById('file-panel-files') as HTMLButtonElement
const outlineTabEl = () => document.getElementById('file-panel-outline') as HTMLButtonElement
const fileToggleBtnEl = () => document.getElementById('file-toggle-btn') as HTMLButtonElement
const sourceToggleBtnEl = () => document.getElementById('source-toggle-btn') as HTMLButtonElement
const wordCountEl = () => document.getElementById('word-count') as HTMLElement
const saveStatusEl = () => document.getElementById('save-status') as HTMLElement
const updateBannerEl = () => document.getElementById('update-banner') as HTMLElement
const updateBannerTextEl = () => document.getElementById('update-banner-text') as HTMLElement
const updateBannerActionEl = () => document.getElementById('update-banner-action') as HTMLButtonElement

// --- Same-directory file panel ---
let currentFilePath: string | null = null
// 当前文档的 file:// URL：图片的相对路径按它解析（文件里存的那串路径不动）。
let currentFileUrl: string | null = null
let fileManagerName: import('../preload/index').FileManagerName = 'file-manager'
let dirty = false
// The active document's YAML frontmatter. It is carried here instead of inside
// the editor: the rich text parser would rewrite it on the way back out, and it
// belongs in the file exactly as it was written (issue #109).
let activeFrontmatter = ''
// The line ending the file on disk uses. The editor hands back `\n` whatever the
// file was written with, and rewriting a Windows file from top to bottom on the
// next save is a change nobody asked for.
let activeLineEnding = '\n'
// Programmatic Markdown replacement dispatches a synchronous ProseMirror
// transaction. Suppress only that transaction, never a time window of input.
let applyingProgrammaticChange = false
// The editor emits updates while it is being built: the initial document plus
// the trailing paragraph it inserts. Those are not user edits, so a document
// must not start out dirty, or closing an untouched new window would ask to
// save it.
let editorReady = false
// Fresh installs start focused on the document. Once changed, the user's
// explicit panel preference is preserved.
// Android 不显示文件列表开关（顶栏按钮与菜单项都去掉了），面板也不再从上次的
// 偏好里恢复：否则它可能停在打开状态，没有任何控件能把它收起来。
let manualHidden = isAndroidApp() || localStorage.getItem('file-panel-hidden') !== '0'
let panelMode: 'files' | 'outline' = 'files'
// The panel has to stay in the DOM for the last part of its closing motion.
// `hidden` still carries the semantic state once that motion finishes, so a
// rapid re-open cancels the pending hide instead of leaving a dead panel.
// `transitionend` is the normal cleanup path; this is only a generous safety
// net for an interrupted or unsupported CSS transition, not a copy of its time.
const PANEL_HIDE_FALLBACK_MS = 500
let panelMotionReady = false
let panelHideCleanup: (() => void) | null = null
let outlineUpdateQueued = false
// Outline doubles as a reading-progress view (#64): the entry for the section
// currently at the top of the viewport is highlighted and kept visible.
// outlineItems only caches source-mode line numbers; visual mode re-queries
// the live DOM at use time because Milkdown recreates heading nodes whenever
// the content is re-set, which silently detaches cached element references.
let outlineItems: OutlineItem[] = []
let outlineActiveIndex = -1
let outlineSyncQueued = false
// While an outline click drives a smooth scroll, scrollspy updates are paused
// so the in-flight scroll events cannot overwrite the clicked entry; the lock
// is released on `scrollend` or by a fallback timer when no scroll happens.
let outlineJumping = false
let outlineJumpTimer: ReturnType<typeof setTimeout> | null = null
let outlineJumpStartTop = 0

// Resizable file panel: default 220px, drag range 180-420px, persisted
// locally (design.md: light, no permanent handle, hover feedback only).
// Applied at module load so the first paint already uses the saved width.
// The strip's start IS the panel's edge line at every width, so the floor is
// only about the panel's own contents as before.
const FILE_PANEL_MIN_WIDTH = 180
const FILE_PANEL_MAX_WIDTH = 420
const FILE_PANEL_DEFAULT_WIDTH = 220
// The width currently applied. Kept beside the CSS variable so a drag that ends
// without moving the pointer does not write the default over the reader's choice.
let filePanelWidth = FILE_PANEL_DEFAULT_WIDTH

function clampFilePanelWidth(width: number): number {
  return Math.min(FILE_PANEL_MAX_WIDTH, Math.max(FILE_PANEL_MIN_WIDTH, Math.round(width)))
}

function applyFilePanelWidth(width: number): void {
  filePanelWidth = width
  document.documentElement.style.setProperty('--file-panel-width', `${width}px`)
}

applyFilePanelWidth(clampFilePanelWidth(Number.parseInt(localStorage.getItem('file-panel-width') ?? '', 10) || FILE_PANEL_DEFAULT_WIDTH))

// Which side the panel sits on. Only the panel moves: the row keeps its shape and
// its three buttons stay at the right end, which is the smallest version of this
// that answers the people who reach for the left (2026-09-20). The preference
// lives here, beside the panel's width, and main is told about it only so the View
// menu's checkmarks tell the truth.
const PANEL_SIDE_KEY = 'colamd-panel-side'

function applyPanelSide(side: string): void {
  const next = side === 'left' ? 'left' : 'right'
  document.body.classList.toggle('panel-left', next === 'left')
  localStorage.setItem(PANEL_SIDE_KEY, next)
  window.electronAPI?.reportPanelSide?.(next)
}

applyPanelSide(localStorage.getItem(PANEL_SIDE_KEY) ?? 'right')

// The reading column's width, three fixed steps chosen from the View menu. The
// preference is a body class rather than an inline style, so the same class
// travels inside the export snapshot and an exported image keeps the column the
// author was reading. `standard` needs no class: it is what body already carries.
const PAGE_WIDTH_KEY = 'colamd-page-width'

const PAGE_WIDTH_CLASSES: Record<string, string> = {
  narrow: 'page-width-narrow',
  standard: '',
  wide: 'page-width-wide'
}

function applyPageWidth(width: string): void {
  const next = width in PAGE_WIDTH_CLASSES ? width : 'standard'
  for (const className of Object.values(PAGE_WIDTH_CLASSES)) {
    if (className) document.body.classList.toggle(className, className === PAGE_WIDTH_CLASSES[next])
  }
  localStorage.setItem(PAGE_WIDTH_KEY, next)
  window.electronAPI?.reportPageWidth?.(next)
}

applyPageWidth(localStorage.getItem(PAGE_WIDTH_KEY) ?? 'standard')

function setMarkdownProgrammatically(content: string, flushHistory = false): void {
  // Every way a document can be replaced at once ends up here (open, external
  // write, new file). The deck's pages are positions in the document that is
  // going away, so the presentation has to end with it.
  if (isPresenting()) stopSlideshow()
  applyingProgrammaticChange = true
  try {
    setMarkdown(content, flushHistory)
  } finally {
    applyingProgrammaticChange = false
  }
}

// --- Unsaved-state tracking + auto-save ---
let autosaveTimer: ReturnType<typeof setTimeout> | null = null
let documentRevision = 0
let saveQueue: Promise<void> = Promise.resolve()

function reportDirty(): void {
  window.electronAPI.reportDirty(dirty)
}

// --- Save status hint (#49) ---
let saveStatusTimer: ReturnType<typeof setTimeout> | null = null
// True while an external-modification conflict waits for the user's choice;
// autosave stays paused so it cannot silently overwrite the external edit.
let externalConflictPending = false

function showSaveStatus(state: 'dirty' | 'saved'): void {
  const el = saveStatusEl()
  if (!el) return
  if (saveStatusTimer) {
    clearTimeout(saveStatusTimer)
    saveStatusTimer = null
  }
  // The dirty hint is gone: the active tab shows a dot for it, and a label in
  // the row was one signal too many. The element stays for the messages that
  // need words, such as an external edit waiting on the user's choice.
  if (state === 'dirty') {
    el.classList.remove('pending')
    el.textContent = ''
  } else {
    el.classList.remove('pending')
    saveStatusTimer = setTimeout(() => {
      el.textContent = ''
    }, 600)
  }
}

function clearSaveStatus(): void {
  if (saveStatusTimer) {
    clearTimeout(saveStatusTimer)
    saveStatusTimer = null
  }
  const el = saveStatusEl()
  if (el) {
    el.classList.remove('pending', 'saved')
    el.textContent = ''
    // The slot is plain text by default (pointer-events: none in the markup);
    // the recovery hint is the one message that can be clicked.
    el.removeAttribute('title')
    el.style.pointerEvents = ''
    el.style.cursor = ''
    el.onclick = null
  }
}

// 移动端没有菜单栏和状态栏，保存这类动作需要一个短暂的确认，
// 否则写进 Documents/colamd 之后界面上什么都看不出来。桌面端不显示。
function showMobileToast(message: string): void {
  if (!isAndroidApp()) return
  const el = document.createElement('div')
  el.textContent = message
  el.style.cssText = 'position:fixed;left:50%;bottom:calc(28px + env(safe-area-inset-bottom));'
    + 'transform:translateX(-50%);z-index:2147483600;max-width:80vw;padding:10px 16px;'
    + 'border-radius:10px;background:var(--chrome-bg,#f2f2f2);color:var(--text-color,#222);'
    + 'font-size:14px;line-height:1.4;box-shadow:0 6px 20px rgba(0,0,0,0.22);'
    + 'opacity:0;transition:opacity 180ms ease;pointer-events:none'
  document.body.appendChild(el)
  requestAnimationFrame(() => { el.style.opacity = '1' })
  window.setTimeout(() => {
    el.style.opacity = '0'
    window.setTimeout(() => el.remove(), 220)
  }, 1600)
}

// After the disk version is loaded, the dropped version still exists in
// ~/.colamd/recovered. Saying so is the entire point of keeping it, so the hint
// takes the save-status slot for a while and opens the folder when clicked.
function showRecoveryHint(recoveryPath: string): void {
  const el = saveStatusEl()
  if (!el) return
  if (saveStatusTimer) {
    clearTimeout(saveStatusTimer)
    saveStatusTimer = null
  }
  el.classList.remove('pending', 'saved')
  el.textContent = isChinese() ? '未保存的内容已存成恢复文件' : 'Unsaved version kept as a recovery file'
  el.title = isChinese() ? '点击在 Finder 中显示' : 'Click to show in the file manager'
  el.style.pointerEvents = 'auto'
  el.style.cursor = 'pointer'
  el.onclick = () => {
    void window.electronAPI?.revealPath?.(recoveryPath)
  }
  saveStatusTimer = setTimeout(() => clearSaveStatus(), 12000)
}

// An external edit landing while the user still has unsaved changes must never
// clobber the editor, and plain autosave would silently overwrite the external
// edit. Pause autosave and let the user choose explicitly.
function raiseExternalConflict(): void {
  if (externalConflictPending) return
  externalConflictPending = true
  if (autosaveTimer) {
    clearTimeout(autosaveTimer)
    autosaveTimer = null
  }
  const el = saveStatusEl()
  if (el) {
    if (saveStatusTimer) {
      clearTimeout(saveStatusTimer)
      saveStatusTimer = null
    }
    el.textContent = isChinese() ? '文件已被外部修改' : 'File changed externally'
    el.classList.remove('saved')
    el.classList.add('pending')
  }
  window.electronAPI.reportExternalConflict?.(getFileContent())
}

// --- Tabs (design.md) ---
// Tabs are created by the user (the + button or ⌘T) and never appear on their own.
// The module-level document state above always describes the ACTIVE tab, so every
// existing path (save, autosave, external conflict, outline, source mode) keeps
// working unchanged. Background tabs keep a snapshot of their own state, which
// makes switching a capture/restore pair instead of a second document machine.
interface DocumentTab {
  id: string
  filePath: string | null
  dirty: boolean
  revision: number
  sourceMode: boolean
  content: string
  frontmatter: string
  lineEnding: string
  editorState: import('@codemirror/state').EditorState | null
  diskContent: string | null
  scrollTop: number
}

const tabs: DocumentTab[] = []
let activeTabId: string | null = null
let nextTabId = 1
let switchingTab = false

const tabBarEl = () => document.getElementById('tab-bar') as HTMLElement

function activeTab(): DocumentTab | null {
  return tabs.find((tab) => tab.id === activeTabId) ?? null
}

// The label for a document that has no path yet, in the current UI language.
let untitledName = 'Untitled'

function untitledLabel(): string {
  return untitledName
}

// The tab carries the document's name, not its file name. `.md` on every tab is
// noise in a strip that hugs its label, and it lands right where the ellipsis
// cuts — `解读.…` reads as four dots. Mirrors the panel's markdown filter.
const DOCUMENT_SUFFIX = /\.(md|markdown|mdown|mkd)$/i

function tabLabel(tab: DocumentTab): string {
  if (!tab.filePath) return untitledLabel()
  const name = tab.filePath.split(/[\\/]/).pop() || tab.filePath
  return name.replace(DOCUMENT_SUFFIX, '')
}

// Read the live state back into the active tab's record. Called before every
// switch, close and bar render, so the records and the screen cannot disagree.
function captureActiveTab(): void {
  const tab = activeTab()
  if (!tab) return
  // The path is the tab's identity and only changes where a document is really
  // opened or saved; deriving it here would let a stray render rename a tab.
  tab.dirty = dirty
  tab.revision = documentRevision
  tab.sourceMode = sourceModeActive
  tab.frontmatter = activeFrontmatter
  tab.lineEnding = activeLineEnding
  tab.content = getFileContent()
  // 源码模式与渲染模式现在共用一个编辑器：状态里自带模式（装饰层的 Compartment 值），
  // 所以两种情况都存同一份 EditorState，不需要另存一份源码文本。
  tab.editorState = getEditorState()
  tab.scrollTop = editorScroller().scrollTop
}

// The bar only carries the unsaved mark that the tab already owns; the title bar
// keeps the primary save hint.
function markActiveTabDirty(): void {
  const tab = activeTab()
  if (!tab) return
  tab.dirty = dirty
  const entry = tabBarEl().querySelector(`.tab-entry[data-tab-id="${tab.id}"]`)
  entry?.classList.toggle('dirty', dirty)
}

// --- The floating label ---
// ONE fixed layer for every name the shell has to shorten: a tab (where it also
// carries ⌘W) and a file-panel row. Neither the strip nor the panel can host it
// — both clip their own overflow — so the renderer positions it.
// A tab waits longer: hovering a tab is usually a prelude to clicking it, and a
// label that jumps out immediately is noise. A row is different — the name is
// what was asked for, so it answers sooner.
const TAB_TIP_DELAY = 1000
const ROW_TIP_DELAY = 450

let tipTimer: ReturnType<typeof setTimeout> | undefined

function showTip(anchor: HTMLElement, text: string, side: 'below' | 'right'): void {
  const tip = document.getElementById('hover-tip') as HTMLElement | null
  if (!tip) return
  tip.textContent = text
  tip.hidden = false
  const rect = anchor.getBoundingClientRect()
  const width = tip.offsetWidth
  if (side === 'right') {
    // Beside the panel and level with the row: the label describes the list, so
    // it must not cover it.
    const height = tip.offsetHeight
    tip.style.left = `${Math.round(Math.min(rect.right + 8, window.innerWidth - width - 8))}px`
    tip.style.top = `${Math.round(Math.min(Math.max(8, rect.top + rect.height / 2 - height / 2), window.innerHeight - height - 8))}px`
    return
  }
  tip.style.left = `${Math.round(Math.min(Math.max(8, rect.left + rect.width / 2 - width / 2), window.innerWidth - width - 8))}px`
  tip.style.top = `${Math.round(rect.bottom + 7)}px`
}

function scheduleTip(anchor: HTMLElement, text: string, side: 'below' | 'right', delay: number): void {
  clearTimeout(tipTimer)
  tipTimer = setTimeout(() => showTip(anchor, text, side), delay)
}

function hideTip(): void {
  clearTimeout(tipTimer)
  const tip = document.getElementById('hover-tip') as HTMLElement | null
  if (tip) tip.hidden = true
}

// A tab whose name fits says nothing but the shortcut; only a truncated name is
// worth spelling out. The full path never appears on hover: it was the system
// tooltip, and it reads as an accident.
function tabTipText(entry: HTMLElement): string {
  const shortcut = '⌘W'
  const name = entry.querySelector('.tab-entry-name') as HTMLElement | null
  const full = entry.dataset.fullName ?? ''
  if (!name || !full) return shortcut
  return name.scrollWidth > name.clientWidth + 1 ? `${full} · ${shortcut}` : shortcut
}

function hideTabTip(): void {
  hideTip()
}
function closeGlyph(): SVGSVGElement {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('width', '9')
  svg.setAttribute('height', '9')
  svg.setAttribute('viewBox', '0 0 9 9')
  svg.setAttribute('fill', 'none')
  svg.setAttribute('stroke', 'currentColor')
  svg.setAttribute('stroke-width', '1.3')
  svg.setAttribute('stroke-linecap', 'round')
  for (const [x1, y1, x2, y2] of [['1.6', '1.6', '7.4', '7.4'], ['7.4', '1.6', '1.6', '7.4']]) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line')
    line.setAttribute('x1', x1); line.setAttribute('y1', y1); line.setAttribute('x2', x2); line.setAttribute('y2', y2)
    svg.append(line)
  }
  return svg
}

// Same plus as the title bar button, at the tab strip's scale.

// The plus at the strip's scale, same shape as the icons in the title bar.
function plusGlyph(): SVGSVGElement {
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
  svg.setAttribute('width', '14')
  svg.setAttribute('height', '14')
  svg.setAttribute('viewBox', '0 0 16 16')
  svg.setAttribute('fill', 'none')
  svg.setAttribute('stroke', 'currentColor')
  svg.setAttribute('stroke-width', '1.3')
  svg.setAttribute('stroke-linecap', 'round')
  for (const [x1, y1, x2, y2] of [['8', '3.1', '8', '12.9'], ['3.1', '8', '12.9', '8']]) {
    const line = document.createElementNS('http://www.w3.org/2000/svg', 'line')
    line.setAttribute('x1', x1); line.setAttribute('y1', y1); line.setAttribute('x2', x2); line.setAttribute('y2', y2)
    svg.append(line)
  }
  return svg
}

function renderTabBar(): void {
  // Android 单窗体：不渲染页签条（一次只编辑一个文档，打开文件直接替换当前内容，
  // 靠「打开文件」/文件列表导航），页签条保持隐藏。
  if (isAndroidApp()) {
    tabBarEl().hidden = true
    return
  }
  captureActiveTab()
  const bar = tabBarEl()
  // The strip is always there: with the layout collapsed into the title bar's
  // row it costs no extra height, and one shape for the chrome beats a title bar
  // that changes personality when a second document appears.
  bar.hidden = false
  // The strip lives inside the title bar's row now, so it consumes no height of
  // its own: the editor starts right under the same 40px row either way.
  // Android 例外：竖屏时页签条是顶栏下方的独立一行，高度由 CSS 按 orientation
  // 决定，这里不能写死内联值（内联会压过媒体查询，旋转后布局就错了）。
  if (!isAndroidApp()) {
    document.documentElement.style.setProperty('--tab-bar-height', '0px')
  }
  document.documentElement.style.setProperty('--editor-top-gap', '0px')
  bar.innerHTML = ''
  // Hide the hover hint unconditionally, including the path where the whole
  // strip disappears (one tab left): a pending timer would otherwise pop "⌘W"
  // for a tab that no longer exists, and a visible hint would never leave —
  // the strip it belongs to is gone, so no mouseleave can fire (#90).
  hideTabTip()
  for (const tab of tabs) {
    const entry = document.createElement('div')
    entry.className = 'tab-entry'
    entry.dataset.tabId = tab.id
    entry.setAttribute('role', 'tab')
    entry.dataset.fullName = tabLabel(tab)
    if (tab.id === activeTabId) {
      entry.classList.add('active')
      entry.setAttribute('aria-selected', 'true')
    }
    if (tab.dirty) entry.classList.add('dirty')
    const name = document.createElement('span')
    name.className = 'tab-entry-name'
    name.textContent = tabLabel(tab)
    const close = document.createElement('button')
    close.type = 'button'
    close.className = 'tab-entry-close'
    close.setAttribute('aria-label', isChinese() ? '关闭标签页' : 'Close tab')
    close.append(closeGlyph())
    entry.append(name, close)
    bar.append(entry)
  }
  // The plus sits right after the strip, not inside it: inside, a full row of
  // tabs scrolled it out of sight exactly when it was needed. It is one of the
  // row's icon controls, so the shared rule styles it and it keeps its gutter
  // from the last tab.
  bar.parentElement?.querySelector('.tab-new-btn')?.remove()
  const add = document.createElement('button')
  add.type = 'button'
  add.className = 'tab-new-btn'
  add.setAttribute('aria-label', isChinese() ? '新建标签页' : 'New tab')
  add.append(plusGlyph())
  add.addEventListener('click', () => void openNewTab())
  add.addEventListener('mouseenter', () => scheduleTip(add, isChinese() ? '新建标签页 · ⌘T' : 'New tab · ⌘T', 'below', TAB_TIP_DELAY))
  add.addEventListener('mouseleave', hideTip)
  bar.after(add)
  const active = bar.querySelector('.tab-entry.active')
  active?.scrollIntoView({ block: 'nearest', inline: 'nearest' })
  // Let the main process know which files this window holds in tabs, so opening
  // an already open document can focus that tab instead of duplicating it.
  window.electronAPI.setTabFiles(tabs.map((tab) => tab.filePath).filter((path): path is string => !!path))
}

function showBlankDocument(): void {
  if (isPresenting()) stopSlideshow()
  exitSourceMode()
  // A blank document carries no properties block from the one before it.
  activeFrontmatter = ''
  activeLineEnding = '\n'
  applyingProgrammaticChange = true
  try {
    setMarkdown('', true)
  } finally {
    applyingProgrammaticChange = false
  }
  updateWordCount('')
  resetDirty()
  updateFileTitle()
  updatePanelVisibility()
  void refreshSiblings()
  scheduleOutlineUpdate()
  editorScroller().scrollTop = 0
}

// Switching away must not lose work. A tab with a path is flushed through the
// usual queue (same rule the file panel already followed); an untitled tab keeps
// its content in its own record and is only decided on when it would really be
// dropped (closing the tab, or closing the window).
async function saveTabForLeaving(tab: DocumentTab | null): Promise<boolean> {
  if (!tab || !tab.dirty || !tab.filePath) return true
  return await saveCurrent()
}

// The window always holds at least one document, so the strip never shows a
// lone plus next to a welcome screen that belongs to no tab: a launch with no
// file seeds the first tab here, and a file that arrives later adopts it.
function ensureTab(): DocumentTab {
  const existing = activeTab()
  if (existing) return existing
  const tab: DocumentTab = {
    id: `tab-${nextTabId++}`,
    filePath: null,
    dirty: false,
    revision: documentRevision,
    sourceMode: false,
    content: '',
    frontmatter: '',
    lineEnding: '\n',
    editorState: null,
    diskContent: null,
    scrollTop: 0
  }
  tabs.push(tab)
  activeTabId = tab.id
  return tab
}

async function openNewTab(): Promise<void> {
  const previous = activeTab()
  captureActiveTab()
  if (!await saveTabForLeaving(previous)) return
  const tab: DocumentTab = {
    id: `tab-${nextTabId++}`,
    filePath: null,
    dirty: false,
    revision: ++documentRevision,
    sourceMode: false,
    content: '',
    frontmatter: '',
    lineEnding: '\n',
    editorState: null,
    diskContent: null,
    scrollTop: 0
  }
  tabs.push(tab)
  activeTabId = tab.id
  currentFilePath = null
  applyDocumentFileUrl(null)
  // Tell the main process the window is now on an untitled document, otherwise
  // its notion of the active file still points at the previous tab's file.
  await window.electronAPI.activateFile(null)
  showBlankDocument()
  renderTabBar()
  // The new tab exists to be typed in, so the caret goes there without a click.
  focusEditor()
}

/**
 * 换文档时告诉编辑器新的图片基准 URL。
 *
 * 文件里写的是相对路径，浏览器要的是绝对地址；解析在画图那一刻做，
 * 这样保存时写回去的还是用户原本写的那串字符。
 */
function applyDocumentFileUrl(url: string | null): void {
  if (url === currentFileUrl) return
  currentFileUrl = url
  setDocumentFileUrl(url)
}

/** 路径刚变过（另存为、自动保存落盘）时，问主进程要一次 URL。 */
async function refreshDocumentFileUrl(): Promise<void> {
  const url = currentFilePath ? await window.electronAPI.fileUrl(currentFilePath) : null
  applyDocumentFileUrl(url)
}

async function activateTab(id: string): Promise<void> {
  if (switchingTab || id === activeTabId) return
  if (isPresenting()) stopSlideshow()
  const target = tabs.find((tab) => tab.id === id)
  if (!target) return
  const previous = activeTab()
  captureActiveTab()
  if (!await saveTabForLeaving(previous)) return
  switchingTab = true
  try {
    // Point the window at the incoming document first: this re-points the file
    // watcher, the title and the recent list, and reports whether the file
    // changed while this tab sat in the background. An untitled tab passes null
    // so the window stops pointing at the tab we are leaving.
    const disk = await window.electronAPI.activateFile(target.filePath)
    applyDocumentFileUrl(disk?.fileUrl ?? null)
    // This document may have been written in a different style than the one we
    // are leaving; its content comes back with it, and the style lives in the
    // content itself, so there is nothing to restore separately.
    activeFrontmatter = target.frontmatter
    activeLineEnding = target.lineEnding
    activeTabId = target.id
    currentFilePath = target.filePath
    documentRevision = target.revision
    dirty = false
    externalConflictPending = false
    const changedOnDisk = !!disk && target.diskContent !== null && disk.content !== target.diskContent
    if (changedOnDisk && !target.dirty) {
      target.diskContent = disk!.content
      setContent(disk!.content, true)
      clearDirty()
      clearSaveStatus()
    } else if (target.editorState) {
      // Swapping in the tab's own editor state is not a user edit. Without this
      // guard the listener fires, the tab flips to 「已编辑」, and an autosave
      // rewrites the file the user never touched.
      applyingProgrammaticChange = true
      try {
        restoreEditorState(target.editorState)
      } finally {
        applyingProgrammaticChange = false
      }
      // 标签的状态里已经带着自己的模式（装饰层 Compartment 的值），外壳这边只把
      // 按钮与 body 类对齐，不再重配一次编辑器。
      applySourceModeUi(target.sourceMode)
    } else if (target.sourceMode) {
      enterSourceMode()
    }
    // The tab's own unsaved state decides, never the swap itself.
    dirty = target.dirty
    reportDirty()
    if (dirty) {
      showSaveStatus('dirty')
      if (!changedOnDisk) scheduleAutosave()
    } else {
      clearSaveStatus()
    }
    updateWordCount()
    updateFileTitle()
    updatePanelVisibility()
    void refreshSiblings()
    scheduleOutlineUpdate()
    const restoreScroll = (): void => {
      editorScroller().scrollTop = target.scrollTop
    }
    restoreScroll()
    requestAnimationFrame(restoreScroll)
    renderTabBar()
    if (changedOnDisk && target.dirty) raiseExternalConflict()
  } finally {
    switchingTab = false
  }
}

async function closeTab(id: string): Promise<void> {
  const index = tabs.findIndex((tab) => tab.id === id)
  if (index < 0) return
  const tab = tabs[index]
  if (tab.id === activeTabId) {
    captureActiveTab()
    if (!await saveTabForLeaving(tab)) return
    if (tab.dirty && !tab.filePath && !confirmDiscardUntitled()) return
  } else if (tab.dirty) {
    // A background tab is not the active document, so it is written straight to
    // its own path; an untitled one cannot be written without a dialog.
    if (tab.filePath) {
      const saved = await window.electronAPI.saveFile(tab.content, tab.filePath, false, false)
      if (!saved) return
      tab.dirty = false
    } else if (!confirmDiscardUntitled()) {
      return
    }
  }
  tabs.splice(index, 1)
  if (tabs.length === 0) {
    // The last tab closed: the window falls back to a single blank document and
    // the bar disappears with it — then asks to close (#132). A clean blank
    // window is not a state the user can reach any other way, and ⌘W used to
    // loop here forever: close the blank, get a fresh blank. If the close is
    // denied (the guard never does for a clean window), the fallback remains.
    activeTabId = null
    await openNewTab()
    void window.electronAPI.closeWindow()
    return
  }
  if (tab.id === activeTabId) {
    activeTabId = null
    await activateTab(tabs[Math.min(index, tabs.length - 1)].id)
  }
  renderTabBar()
}

// An untitled tab has nowhere to go on disk, so closing it asks first.
function confirmDiscardUntitled(): boolean {
  return window.confirm(isChinese()
    ? '这个标签页还没有保存，关闭会丢掉里面的内容。'
    : 'This tab has unsaved content. Close it anyway?')
}

// Open a file in a tab of its own. Reuses a blank current tab, and never opens
// the same file twice: an already open document just gets focused.
async function openFileInNewTab(path: string): Promise<void> {
  const existing = tabs.find((tab) => tab.filePath === path)
  if (existing) {
    await activateTab(existing.id)
    return
  }
  const current = activeTab()
  if (current && !current.filePath && !current.dirty) {
    await window.electronAPI.openSibling(path)
    return
  }
  await openNewTab()
  // Claim the path before the 'file-opened' round-trip lands: a burst of
  // queued tab-opens would otherwise see this tab as still blank and reuse it
  // for the next file, overwriting the one just opened (#99).
  const claimed = activeTab()
  // A failed save can prevent openNewTab from creating a tab. Keep the source.
  if (!claimed || claimed === current) return
  claimed.filePath = path
  await window.electronAPI.openSibling(path)
}

// Closing several tabs runs one at a time: each close may need its own unsaved
// confirmation, and a cancelled one stops the rest.
async function closeTabsMatching(keep: (index: number) => boolean): Promise<void> {
  for (;;) {
    const index = tabs.findIndex((_tab, i) => keep(i))
    if (index < 0) return
    const before = tabs.length
    await closeTab(tabs[index].id)
    if (tabs.length === before) return
  }
}

function bindTabBar(api: import('../preload/index').ElectronAPI): void {
  // Tab-opens are serialized: each request awaits main (activateFile,
  // file-opened) before the next runs. Without this, a burst of queued opens
  // (multi-file launch, fast second-instance) interleaves and two documents
  // land in one tab (#99).
  let tabOpenQueue: Promise<void> = Promise.resolve()
  const enqueueTabOpen = (path: string, fragment?: string, line?: number): void => {
    tabOpenQueue = tabOpenQueue.then(async () => {
      await openFileInNewTab(path)
      if ((!fragment && line === undefined) || currentFilePath !== path) return
      // Run after the tab's scroll restoration. Hidden windows suspend frames,
      // so visual work must not block subsequent requests in the open queue.
      requestAnimationFrame(() => requestAnimationFrame(() => {
        if (currentFilePath !== path) return
        if (line !== undefined) {
          // 两种模式共用一个编辑器，行号跳转不需要再分路。
          jumpToLine(Math.min(line, getMarkdown().split('\n').length) - 1)
          return
        }
        jumpToHeading(fragment!)
      }))
    }).catch(() => { /* next file still opens */ })
  }
  // Tabs are also created from the File menu / ⌘T and from the file list; the
  // strip's own plus is bound above, in renderTabBar.
  api.onMenuNewTab(() => { void openNewTab() })
  api.onMenuCloseTab(() => { if (activeTabId) void closeTab(activeTabId) })
  api.onOpenInNewTab(enqueueTabOpen)
  const handleTabMenuAction = ({ action, tabId }: { action: string; tabId: string }) => {
    if (action === 'close') { void closeTab(tabId); return }
    if (action === 'close-others') { void closeTabsMatching((i) => tabs[i].id !== tabId); return }
    if (action === 'close-right') {
      void closeTabsMatching((i) => i > tabs.findIndex((tab) => tab.id === tabId))
    }
  }
  api.onTabMenuAction(handleTabMenuAction)
  // Chromium re-dispatches hover events after the DOM under the pointer changes,
  // with the same coordinates. Closing a tab rebuilds the strip, so the hint used
  // to re-arm itself under a pointer that never moved and looked like it refused
  // to go away (#90). A real hover always comes with new coordinates.
  let lastHoverPoint = ''
  tabBarEl().addEventListener('mouseover', (e) => {
    const point = `${e.clientX},${e.clientY}`
    if (point === lastHoverPoint) return
    lastHoverPoint = point
    const target = e.target as HTMLElement
    const entry = target.closest('.tab-entry') as HTMLElement | null
    if (entry) scheduleTip(entry, tabTipText(entry), 'below', TAB_TIP_DELAY)
    else hideTabTip()
  })
  tabBarEl().addEventListener('mouseleave', () => {
    // Leaving clears the gate: coming back to the same pixel is a real hover.
    lastHoverPoint = ''
    hideTabTip()
  })
  tabBarEl().addEventListener('contextmenu', (e) => {
    const entry = (e.target as HTMLElement).closest('.tab-entry') as HTMLElement | null
    const id = entry?.dataset.tabId
    if (!id) return
    const index = tabs.findIndex((tab) => tab.id === id)
    if (index < 0) return
    e.preventDefault()
    void api.showTabContextMenu({
      tabId: id,
      filePath: tabs[index].filePath,
      canCloseOthers: tabs.length > 1,
      canCloseRight: index < tabs.length - 1
    })
  })
  api.onFocusFile((path) => {
    const tab = tabs.find((candidate) => candidate.filePath === path)
    if (tab) void activateTab(tab.id)
  })
  tabBarEl().addEventListener('click', (e) => {
    const target = e.target as HTMLElement
    const entry = target.closest('.tab-entry') as HTMLElement | null
    const id = entry?.dataset.tabId
    if (!id) return
    if (target.closest('.tab-entry-close')) {
      void closeTab(id)
      return
    }
    void activateTab(id)
  })
  // Middle click closes, the browser convention; the bar stays free of a
  // permanent close affordance (design.md).
  tabBarEl().addEventListener('auxclick', (e) => {
    if (e.button !== 1) return
    const entry = (e.target as HTMLElement).closest('.tab-entry') as HTMLElement | null
    const id = entry?.dataset.tabId
    if (!id) return
    e.preventDefault()
    void closeTab(id)
  })
}

// Keep the active tab's record in step with a successful write, so switching
// back to it later can tell whether the file changed underneath us.
function noteTabSaved(content: string): void {
  const tab = activeTab()
  if (!tab) return
  tab.diskContent = content
  tab.filePath = currentFilePath
  tab.dirty = dirty
}

function setDirty(): void {
  documentRevision += 1
  dirty = true
  reportDirty()
  showSaveStatus('dirty')
  markActiveTabDirty()
  scheduleAutosave()
}

function clearDirty(): void {
  dirty = false
  if (autosaveTimer) {
    clearTimeout(autosaveTimer)
    autosaveTimer = null
  }
  reportDirty()
  markActiveTabDirty()
}

// Invalidate any in-flight save captured from the previous document before
// replacing editor content from disk.
function resetDirty(): void {
  documentRevision += 1
  clearDirty()
  clearSaveStatus()
}

function enqueueSave(operation: () => Promise<string | null>): Promise<string | null> {
  const next = saveQueue.then(operation, operation)
  saveQueue = next.then(() => undefined, () => undefined)
  return next
}

function scheduleAutosave(): void {
  if (!currentFilePath) return
  // Paused while an external-modification conflict is unresolved: the user
  // must decide between their version and the disk version first.
  if (externalConflictPending) return
  if (autosaveTimer) clearTimeout(autosaveTimer)
  autosaveTimer = setTimeout(() => {
    autosaveTimer = null
    void runAutosave()
  }, 1000)
}

async function runAutosave(): Promise<void> {
  if (!dirty || !currentFilePath) return
  const revision = documentRevision
  const filePath = currentFilePath
  const content = getFileContent()
  // rebuildMenu=false: autosave must never rebuild the app menu (macOS IME)
  // autosave=true: the main process may refuse the write when the file changed
  // on disk since our last read or write, and ask the user instead.
  const path = await enqueueSave(() => window.electronAPI.saveFile(content, filePath, false, true))
  if (path && revision === documentRevision && currentFilePath === filePath) {
    if (path !== filePath) void refreshDocumentFileUrl()
    currentFilePath = path
    clearDirty()
    noteTabSaved(content)
    showSaveStatus('saved')
  }
}

async function saveCurrent(saveAs = false): Promise<boolean> {
  const revision = documentRevision
  const content = getFileContent()
  const expectedPath = currentFilePath
  // '' states plainly that the active document is untitled, so a save can never
  // be written into a file the window happens to have open in another tab.
  const path = await enqueueSave(() => saveAs
    ? window.electronAPI.saveFileAs(content, expectedPath ?? '')
    : window.electronAPI.saveFile(content, expectedPath ?? '', true))
  if (!path || currentFilePath !== expectedPath) {
    showMobileToast(isChinese() ? '保存失败' : 'Save failed')
    return false
  }

  if (path !== expectedPath) void refreshDocumentFileUrl()
  currentFilePath = path
  updateFileTitle()
  refreshSiblings()
  noteTabSaved(content)
  if (path !== expectedPath) renderTabBar()
  if (revision === documentRevision) {
    clearDirty()
    showSaveStatus('saved')
    showMobileToast(isChinese()
      ? `已保存：${path.split('/').pop() ?? path}`
      : `Saved: ${path.split('/').pop() ?? path}`)
    return true
  }
  if (dirty) scheduleAutosave()
  return false
}

function applyContent(content: string): void {
  // Reached only when the document identity changes (New file, loading a disk
  // version after an external conflict), so the undo stack must not survive.
  setContent(content, true)
}

// --- Document statistics (top-right hover indicator) ---
function countCharacters(content: string): number {
  return content.replace(/\s/g, '').length
}

function countTokens(content: string): number {
  const tokens = content.match(/[\u3400-\u4DBF\u4E00-\u9FFF\uF900-\uFAFF\u3040-\u30FF\uAC00-\uD7AF]|[A-Za-z]+(?:['’\\-][A-Za-z]+)*|\d+(?:[.,]\d+)*/g)
  return tokens?.length ?? 0
}

function countParagraphs(content: string): number {
  const normalized = content.replace(/\r\n?/g, '\n').trim()
  return normalized ? normalized.split(/\n\s*\n+/).filter((block) => block.trim()).length : 0
}

function setToolbarTip(el: HTMLElement, label: string): void {
  el.setAttribute('aria-label', label)
  const tip = el.querySelector('.toolbar-tip')
  if (tip) tip.textContent = label
}

function updateWordCount(content?: string): void {
  const text = content ?? getContent()
  setToolbarTip(wordCountEl(), isChinese()
    ? `${countCharacters(text)} 字 · ${countTokens(text)} 词 · ${countParagraphs(text)} 段`
    : `${countCharacters(text)} chars · ${countTokens(text)} words · ${countParagraphs(text)} paragraphs`)
}

// --- Reveal the current file in the OS file manager ---
function fileLocationLabel(): string {
  if (isChinese()) {
    return fileManagerName === 'finder'
      ? '在 Finder 中显示'
      : fileManagerName === 'explorer'
        ? '在资源管理器中显示'
        : '打开所在文件夹'
  }
  return fileManagerName === 'finder'
    ? 'Reveal in Finder'
    : fileManagerName === 'explorer'
      ? 'Reveal in File Explorer'
      : 'Open Containing Folder'
}

// The titlebar is a window drag region, so the button cannot rely on
// `#titlebar:hover`. Its gate lives on the file title instead; this keeps the
// label and the disabled state in sync with the loaded document.
// --- Markdown source / WYSIWYG toggle ---
function updateSourceToggle(): void {
  const btn = sourceToggleBtnEl()
  btn.classList.toggle('active', sourceModeActive)
  const label = sourceModeActive
    ? (isChinese() ? '切换回所见即所得' : 'Switch to WYSIWYG')
    : (isChinese() ? '切换 Markdown 源码' : 'Switch to Markdown source')
  setToolbarTip(btn, label)
}

function updateUiLanguage(): void {
  const zh = isChinese()
  document.documentElement.lang = zh ? 'zh-CN' : 'en'
  document.title = 'ColaMD'
  untitledName = zh ? '未命名' : 'Untitled'
  fileTabEl().textContent = zh ? '文件' : 'Files'
  outlineTabEl().textContent = zh ? '大纲' : 'Outline'
  setToolbarTip(fileToggleBtnEl(), zh ? '显示 / 隐藏文件列表 (⌘\\)' : 'Show / Hide File List (⌘\\)')
  const menuBtn = document.getElementById('app-menu-btn')
  if (menuBtn) setToolbarTip(menuBtn, zh ? '菜单' : 'Menu')
  updateSourceToggle()
  updateWordCount()
}
function scrollRatio(el: HTMLElement): number {
  const range = el.scrollHeight - el.clientHeight
  return range > 0 ? el.scrollTop / range : 0
}

function restoreScrollRatio(el: HTMLElement, ratio: number): void {
  const range = el.scrollHeight - el.clientHeight
  el.scrollTop = Math.max(0, Math.min(range, range * ratio))
}

function toggleSourceMode(): void {
  // 两种模式是同一个缓冲区、同一个滚动容器，只有排版高度不同，所以按比例还原位置。
  const ratio = scrollRatio(editorScroller())
  if (sourceModeActive) exitSourceMode()
  else enterSourceMode()
  restoreScrollRatio(editorScroller(), ratio)
  updateWordCount()
  scheduleOutlineUpdate()
}

function cancelPendingPanelHide(): void {
  panelHideCleanup?.()
  panelHideCleanup = null
}

function hidePanelAfterTransition(panel: HTMLElement): void {
  const finish = () => {
    cleanup()
    // A second toggle may have re-opened the panel while the close transition
    // was still in flight. Only the state that is still closed may hide it.
    if (!document.body.classList.contains('show-file-panel')) panel.hidden = true
  }
  const onTransitionEnd = (event: TransitionEvent) => {
    if (event.target === panel && event.propertyName === 'transform') finish()
  }
  const timeout = window.setTimeout(finish, PANEL_HIDE_FALLBACK_MS)
  const cleanup = () => {
    window.clearTimeout(timeout)
    panel.removeEventListener('transitionend', onTransitionEnd)
    if (panelHideCleanup === cleanup) panelHideCleanup = null
  }
  panel.addEventListener('transitionend', onTransitionEnd)
  panelHideCleanup = cleanup
}

function updatePanelVisibility(): void {
  const show = !manualHidden
  const panel = filePanelEl()
  cancelPendingPanelHide()

  if (show) {
    // Start from the off-canvas CSS state, then enter it on the next style
    // change. Reading offsetWidth deliberately commits that start position,
    // otherwise display:none → visible would skip the opening transition.
    panel.hidden = false
    panel.setAttribute('aria-hidden', 'false')
    if (!document.body.classList.contains('show-file-panel')) {
      if (panelMotionReady) void panel.offsetWidth
      document.body.classList.add('show-file-panel')
    }
  } else {
    // A delayed `hidden` keeps the exit motion visible. If a file-row button
    // owned focus, move it out before exposing an aria-hidden subtree.
    if (panel.contains(document.activeElement)) fileToggleBtnEl().focus()
    panel.setAttribute('aria-hidden', 'true')
    document.body.classList.remove('show-file-panel')
    if (panelMotionReady && !panel.hidden && !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      hidePanelAfterTransition(panel)
    } else {
      panel.hidden = true
    }
  }

  fileToggleBtnEl().classList.toggle('active', show)
  fileListEl().hidden = panelMode !== 'files'
  outlineListEl().hidden = panelMode !== 'outline'
  fileTabEl().classList.toggle('active', panelMode === 'files')
  fileTabEl().setAttribute('aria-selected', String(panelMode === 'files'))
  outlineTabEl().classList.toggle('active', panelMode === 'outline')
  outlineTabEl().setAttribute('aria-selected', String(panelMode === 'outline'))

  // Avoid animating a restored visible panel on the initial paint. Every later
  // keyboard/menu/button toggle uses the same motion.
  if (!panelMotionReady) {
    requestAnimationFrame(() => {
      panelMotionReady = true
      document.body.classList.add('panel-motion-ready')
    })
  }
}

function setPanelMode(mode: 'files' | 'outline'): void {
  panelMode = mode
  updatePanelVisibility()
  if (mode === 'outline') renderOutline()
}

interface OutlineItem {
  level: number
  title: string
  line?: number
}

function sourceOutline(content: string): OutlineItem[] {
  const items: OutlineItem[] = []
  // 代码围栏里的 `#` 是注释，不是标题（#137：Python、shell、YAML 的注释都进过大纲）。
  // 记一下当前在不在围栏里，以及是哪种围栏、多长：```` 开头的块里出现 ``` 不算闭合。
  let fence: { char: string; length: number } | null = null
  content.split(/\r?\n/).forEach((line, index) => {
    const fenceMatch = /^\s{0,3}(`{3,}|~{3,})/.exec(line)
    if (fenceMatch) {
      const marker = fenceMatch[1]
      if (!fence) {
        fence = { char: marker[0], length: marker.length }
      } else if (marker[0] === fence.char && marker.length >= fence.length) {
        fence = null
      }
      return
    }
    if (fence) return
    const match = /^(#{1,6})\s+(.+?)(?:\s+#+)?\s*$/.exec(line)
    if (!match) return
    const title = match[2].replace(/!?(?:\[([^\]]*)\])\([^)]*\)/g, '$1').replace(/[*_`]/g, '').trim()
    if (title) items.push({ level: match[1].length, title, line: index })
  })
  return items
}

// 大纲从源码文本里读，不从渲染后的 DOM 里找。
//
// 旧实现是查 `#editor .ProseMirror h1…h6`，因为 ProseMirror 会把标题渲成真的 <h1> 标签。
// CodeMirror 不这样做：标题只是带上装饰的一行文本。从文本解析本来就更该是对的做法，
// 它跟「怎么画」无关，源码模式与渲染模式共用同一份逻辑（缓冲区也是同一份）。

function outlineVisible(): boolean {
  return !manualHidden && panelMode === 'outline'
}

function renderOutline(): void {
  // The outline is only ever read from the panel, which is hidden by default.
  // Rebuilding it on every keystroke (and on every scroll) burned a full DOM
  // teardown plus forced layout per frame for output nobody could see.
  if (!outlineVisible()) return
  const list = outlineListEl()
  outlineItems = sourceOutline(getMarkdown())
  list.innerHTML = ''
  if (outlineItems.length === 0) {
    outlineActiveIndex = -1
    return
  }
  outlineItems.forEach((item, index) => {
    const entry = document.createElement('li')
    const button = document.createElement('button')
    button.dataset.headingIndex = String(index)
    button.type = 'button'
    button.textContent = item.title
    // Hover keeps truncated headings readable while the panel width stays
    // as-is in this change (#64).
    button.title = item.title
    button.style.paddingLeft = `${8 + (item.level - 1) * 12}px`
    button.addEventListener('click', () => {
      // Re-resolve the entry against the live text: cached references die when
      // the editor content is re-set (#64).
      const current = sourceOutline(getMarkdown())[index]
      if (!current || current.line === undefined) return
      // 两种模式共用一个编辑器：交给它自己跳，它会同时把光标放过去。
      // flashHeadingOnArrival 的信号靠编辑器内部的落点装饰发出，这里只管跳。
      beginOutlineJump()
      jumpToLine(current.line)
      setActiveOutlineIndex(index)
    })
    entry.appendChild(button)
    list.appendChild(entry)
  })
  applyOutlineActive()
  scheduleOutlineActiveSync()
}

function applyOutlineActive(): void {
  const list = outlineListEl()
  const buttons = list.querySelectorAll<HTMLButtonElement>('button')
  buttons.forEach((button, index) => {
    button.classList.toggle('active', index === outlineActiveIndex)
  })
  // Keep the tracked section visible in long documents.
  const active = buttons[outlineActiveIndex]
  if (active) revealOutlineEntry(active)
}

// Manual reveal of the active entry inside the panel. scrollIntoView() must
// not be used here: it would also interrupt the smooth scroll of the content
// pane started by an outline click, so only the panel's own scroller moves.
function revealOutlineEntry(button: HTMLButtonElement): void {
  const panel = filePanelEl()
  const panelTop = panel.getBoundingClientRect().top
  const top = button.getBoundingClientRect().top - panelTop + panel.scrollTop
  const bottom = top + button.offsetHeight
  if (top < panel.scrollTop) {
    panel.scrollTop = top
  } else if (bottom > panel.scrollTop + panel.clientHeight) {
    panel.scrollTop = bottom - panel.clientHeight
  }
}

function beginOutlineJump(): void {
  outlineJumping = true
  if (outlineJumpTimer) clearTimeout(outlineJumpTimer)
  outlineJumpStartTop = editorScroller().scrollTop
  // scrollend releases the lock earlier; this fallback exists for the
  // no-scroll case. Re-arming while the position keeps changing keeps long
  // smooth jumps locked for their whole duration (review on #68).
  outlineJumpTimer = setTimeout(releaseOutlineJumpIfSettled, 1500)
}

function releaseOutlineJumpIfSettled(): void {
  if (!outlineJumping) return
  const top = editorScroller().scrollTop
  if (top !== outlineJumpStartTop) {
    outlineJumpStartTop = top
    outlineJumpTimer = setTimeout(releaseOutlineJumpIfSettled, 400)
    return
  }
  endOutlineJump()
}

function endOutlineJump(): void {
  if (!outlineJumping) return
  outlineJumping = false
  if (outlineJumpTimer) {
    clearTimeout(outlineJumpTimer)
    outlineJumpTimer = null
  }
  scheduleOutlineActiveSync()
}

function setActiveOutlineIndex(index: number): void {
  if (index === outlineActiveIndex) return
  outlineActiveIndex = index
  applyOutlineActive()
}

function scheduleOutlineActiveSync(): void {
  if (!outlineVisible()) return
  if (outlineJumping) return
  if (outlineSyncQueued) return
  outlineSyncQueued = true
  requestAnimationFrame(() => {
    outlineSyncQueued = false
    syncOutlineActive()
  })
}

// Scrollspy: highlight the outline entry for the section at the top of the
// viewport so the outline tracks reading progress (#64).
function syncOutlineActive(): void {
  if (outlineItems.length === 0) return
  setActiveOutlineIndex(visualActiveIndex())
}

// 阅读进度：拿每一条标题所在行在正文坐标系里的位置，跟视口顶部比。两种模式共用同一个
// 编辑器与滚动容器，所以这套算法对源码模式同样成立。
//
// 旧实现找的是 DOM 里的 <h1>…<h6> 元素（ProseMirror 会把标题渲成真标签）。CodeMirror 不产
// 生这些元素，标题只是带装饰的一行文字，所以改成用编辑器自己的行位置来算：
// lineBlockAt 给出行在正文坐标系里的 top，减去滚动量就是它相对视口的位置。
function visualActiveIndex(): number {
  const view = getEditorView()
  if (!view) return -1
  const container = editorScroller()
  const atBottom = container.scrollTop + container.clientHeight >= container.scrollHeight - 2
  if (atBottom) return outlineItems.length - 1
  const threshold = Math.min(96, container.clientHeight * 0.2)
  let index = -1
  for (let i = 0; i < outlineItems.length; i += 1) {
    const line = outlineItems[i].line
    if (line === undefined || line >= view.state.doc.lines) continue
    const top = view.lineBlockAt(view.state.doc.line(line + 1).from).top
    if (top - container.scrollTop > threshold) break
    index = i
  }
  return index
}

function scheduleOutlineUpdate(): void {
  if (!outlineVisible()) return
  if (outlineUpdateQueued) return
  outlineUpdateQueued = true
  requestAnimationFrame(() => {
    outlineUpdateQueued = false
    renderOutline()
  })
}

function togglePanel(): void {
  manualHidden = !manualHidden
  localStorage.setItem('file-panel-hidden', manualHidden ? '1' : '0')
  updatePanelVisibility()
}

// Drag the panel's inner edge to resize it; the width clamps to the
// FILE_PANEL_* range and persists on release. Pointer capture keeps the drag
// alive over iframes and selected text.
function initPanelResize(): void {
  const resizer = document.getElementById('panel-resizer') as HTMLDivElement | null
  if (!resizer) return
  resizer.addEventListener('pointerdown', (event) => {
    event.preventDefault()
    resizer.setPointerCapture(event.pointerId)
    resizer.classList.add('dragging')
    document.body.classList.add('panel-resizing')
    // The width is the pointer's distance from the edge the panel hangs off, and
    // that edge is not always the right one (#118): measuring the left side from
    // the window's right edge pinned the panel to the maximum on the first move.
    const onLeft = document.body.classList.contains('panel-left')
    let width = filePanelWidth
    const move = (moveEvent: PointerEvent) => {
      width = clampFilePanelWidth(onLeft ? moveEvent.clientX : window.innerWidth - moveEvent.clientX)
      applyFilePanelWidth(width)
    }
    const finish = () => {
      resizer.removeEventListener('pointermove', move)
      resizer.removeEventListener('pointerup', finish)
      resizer.removeEventListener('pointercancel', finish)
      resizer.classList.remove('dragging')
      document.body.classList.remove('panel-resizing')
      localStorage.setItem('file-panel-width', String(width))
    }
    resizer.addEventListener('pointermove', move)
    resizer.addEventListener('pointerup', finish)
    resizer.addEventListener('pointercancel', finish)
  })
}

function updateFileTitle(): void {
  // The filename is shown by the tab; the window title is the only place left
  // that needs it spelled out (there is no centred title in the title bar).
  const name = currentFilePath ? (currentFilePath.split(/[\\/]/).pop() || currentFilePath) : (isChinese() ? '未命名' : 'Untitled')
  document.title = name
}

// --- File panel: one root, expanded downward ---
// The root is the open document's directory and `..` stays the one way back
// up; a directory is read only when it is expanded, so a deep tree costs
// nothing until the reader asks for it. Expansion lives in memory only — no
// workspace, nothing restored on the next launch.
const PANEL_INDENT = 12
let panelRoot: import('../preload/index').SiblingFile[] = []
const panelChildren = new Map<string, import('../preload/index').SiblingFile[]>()
const panelExpanded = new Set<string>()
const panelLoading = new Set<string>()

type PanelRow = {
  file: import('../preload/index').SiblingFile
  depth: number
  expandable: boolean
  expanded: boolean
  empty: boolean
}

// Flatten the expanded tree into visible rows. Rendering stays a flat list, so
// hover, active state and hit-testing keep working the way they always have.
function panelRows(): PanelRow[] {
  const rows: PanelRow[] = []
  const walk = (entries: import('../preload/index').SiblingFile[], depth: number): void => {
    for (const file of entries) {
      const expanded = file.kind === 'directory' && panelExpanded.has(file.path)
      rows.push({ file, depth, expandable: file.kind === 'directory', expanded, empty: false })
      if (!expanded) continue
      const children = panelChildren.get(file.path)
      if (!children) {
        void loadPanelDirectory(file.path)
        continue
      }
      if (children.length === 0) rows.push({ file, depth: depth + 1, expandable: false, expanded: false, empty: true })
      else walk(children, depth + 1)
    }
  }
  walk(panelRoot, 0)
  return rows
}

function loadPanelDirectory(dir: string): void {
  if (panelLoading.has(dir)) return
  panelLoading.add(dir)
  void window.electronAPI.listDirectory(dir).then((children) => {
    panelLoading.delete(dir)
    if (!children) return
    panelChildren.set(dir, children)
    renderFileList(panelRoot)
  })
}

function togglePanelDirectory(dir: string): void {
  if (panelExpanded.has(dir)) panelExpanded.delete(dir)
  else {
    panelExpanded.add(dir)
    loadPanelDirectory(dir)
  }
  renderFileList(panelRoot)
}

function renderFileList(files: import('../preload/index').SiblingFile[]): void {
  panelRoot = files
  hideTip()
  const list = fileListEl()
  list.innerHTML = ''
  for (const row of panelRows()) {
    const li = document.createElement('li')
    const indent = 8 + row.depth * PANEL_INDENT
    if (row.empty) {
      const empty = document.createElement('div')
      empty.className = 'file-empty'
      empty.style.paddingLeft = `${indent}px`
      empty.textContent = isChinese() ? '这个文件夹是空的' : 'This folder is empty'
      li.appendChild(empty)
      list.appendChild(li)
      continue
    }
    const f = row.file
    const btn = document.createElement('button')
    btn.style.paddingLeft = `${indent}px`
    const chevron = document.createElement('span')
    chevron.className = `file-entry-chevron${row.expanded ? ' expanded' : ''}${f.kind === 'parent' ? ' back' : ''}`
    chevron.setAttribute('aria-hidden', 'true')
    // Same 10-unit box and stroke as the expander chevrons: drawing the way back
    // in a 16-unit box scaled into the same 10px slot made it smaller and its
    // stroke lighter, so the two arrows read as different controls (2026-09-15).
    if (f.kind === 'parent') chevron.innerHTML = '<svg viewBox="0 0 10 10"><path d="M8.5 5H2M4.5 2.5 2 5l2.5 2.5"/></svg>'
    else if (row.expandable) chevron.innerHTML = '<svg viewBox="0 0 10 10"><path d="M3.5 1.5 7 5l-3.5 3.5"/></svg>'
    const icon = document.createElement('span')
    icon.className = `file-entry-icon ${f.kind}`
    icon.setAttribute('aria-hidden', 'true')
    icon.innerHTML = f.kind === 'directory'
      ? '<svg viewBox="0 0 16 16"><path d="M2.5 4.5h4l1.5 1.5h6v6.5h-11.5z"/><path d="M2.5 4.5v-1h4l1.5 1.5"/></svg>'
      : '<svg viewBox="0 0 16 16"><path d="M4 2.5h5l3 3v8H4z"/><path d="M9 2.5v3h3"/></svg>'
    const label = document.createElement('span')
    label.className = 'file-entry-name'
    // Words, not two dots: the row has the space and ".." never said where it goes.
    label.textContent = f.kind === 'parent' ? (isChinese() ? '返回' : 'Back') : f.name
    btn.addEventListener('mouseenter', () => {
      // Only a name that is actually cut off is worth a label; one that fits
      // says itself. No marquee: sliding the name under the icon to read it
      // covers the row it belongs to.
      if (label.scrollWidth <= label.clientWidth + 1) return
      scheduleTip(btn, label.textContent ?? '', 'right', ROW_TIP_DELAY)
    })
    btn.addEventListener('mouseleave', hideTip)
    btn.title = f.kind === 'directory'
      ? (isChinese()
          ? `${row.expanded ? '收起' : '展开'} ${f.name}`
          : `${row.expanded ? 'Collapse' : 'Expand'} ${f.name}`)
      : f.kind === 'parent' ? (isChinese() ? '返回上级目录' : 'Go to parent directory') : f.name
    btn.dataset.path = f.path
    btn.dataset.kind = f.kind
    btn.classList.toggle('directory', f.kind === 'directory')
    btn.classList.toggle('parent', f.kind === 'parent')
    if (f.path === currentFilePath) btn.classList.add('active')
    // The way back sits in the expander's column and its name takes the icon's,
    // so the row reads left to right like every other one instead of hanging a
    // column in. It has no icon of its own, which is why no slot is skipped.
    if (f.kind === 'parent') btn.append(chevron, label)
    else btn.append(chevron, icon, label)
    li.appendChild(btn)
    list.appendChild(li)
  }
}

async function refreshSiblings(): Promise<void> {
  const files = await window.electronAPI.listSiblings()
  if (files) renderFileList(files)
}

// 源码模式不是第二个编辑器（见 editor/core.ts 的 livePreviewCompartment）：
// 这里只同步外壳（按钮、body 类），真正的切换是关掉渲染装饰层。
function applySourceModeUi(on: boolean): void {
  if (sourceModeActive === on) return
  sourceModeActive = on
  document.body.classList.toggle('source-mode', on)
  updateSourceToggle()
}

function enterSourceMode(): void {
  applySourceModeUi(true)
  setSourceMode(true)
}

function exitSourceMode(): void {
  if (!sourceModeActive) return
  applySourceModeUi(false)
  setSourceMode(false)
}

const LARGE_DOCUMENT_SOURCE_THRESHOLD = 512 * 1024

// 一份完整的文件从磁盘到达：打开，或外部改写之后的重载。
//
// 文本优先之后属性区不再需要拆出来单独保管：它本来就是正文开头的几行，编辑器原样
// 拿着它，保存时原样写回去。这个函数现在只做一件事：记下行尾。
function takeFrontmatter(fileText: string): string {
  activeFrontmatter = ''
  activeLineEnding = fileText.includes('\r\n') ? '\r\n' : '\n'
  return fileText
}

function setContent(content: string, flushHistory = false): void {
  const body = takeFrontmatter(content)
  const large = body.length >= LARGE_DOCUMENT_SOURCE_THRESHOLD
  if (large) {
    // 装饰层是**整篇**重算的（live-preview 的 StateField），半兆以上的文档每次敲键都要
    // 重算一遍全篇，打字会卡。所以超大文件仍然进源码模式——渲染不参与，编辑就快。
    // 模式要在换文本之前切：换文本会按当前状态重建扩展表，模式跟着状态走，
    // 这样不会先为整篇算一遍装饰。
    enterSourceMode()
  }
  setMarkdownProgrammatically(body, flushHistory)
  if (!large) exitSourceMode()
  updateWordCount(body)
}

function getContent(): string {
  return getMarkdown()
}

// What belongs in the file: the properties block untouched, then the document
// in the line endings the file already used.
function getFileContent(): string {
  const body = getContent()
  return activeFrontmatter + (activeLineEnding === '\r\n' ? body.replace(/\r?\n/g, '\r\n') : body)
}

/**
 * 导出前把编辑器的痕迹收起来，导出后放回去。
 *
 * 「痕迹」有两样：光标所在那一行会显形源码（光标停在标题上，导出的就是 `# 标题`），
 * 以及光标与选区本身。两样都不是文档的内容。
 */
async function withCleanExport<T>(run: () => Promise<T>): Promise<T> {
  setCleanExport(true)
  document.body.classList.add('exporting')
  try {
    return await run()
  } finally {
    setCleanExport(false)
    document.body.classList.remove('exporting')
  }
}

/**
 * 导出前把窗口摆成「纸」，导完收回去。
 *
 * 两件事：
 * ① 藏起编辑器的痕迹：当前行不再显形源码（状态层开关），光标、选区、属性区由
 *    `body.exporting` 交给 CSS。导出的是一篇文档，不是编辑器此刻的样子。
 * ② 摊平成块流，等 CodeMirror 把整篇渲染出来。不做这一步，快照里只有当前视口那一屏。
 */
async function withExportLayout<T>(run: () => Promise<T>): Promise<T> {
  setCleanExport(true)
  document.body.classList.add('exporting')
  try {
    await enterPaperLayout()
    return await run()
  } finally {
    exitPaperLayout()
    setCleanExport(false)
    document.body.classList.remove('exporting')
  }
}

function getExportSnapshot(content: string): {
  content: string
  html: string
  document: string
  styles: string
  bodyClass: string
  background: string
} {
  let styles = ''
  for (const sheet of Array.from(document.styleSheets)) {
    try {
      styles += Array.from(sheet.cssRules).map((rule) => rule.cssText).join('\n') + '\n'
    } catch {
      // Ignore stylesheets that the browser marks as inaccessible.
    }
  }
  const editorRoot = document.querySelector<HTMLElement>('#editor .cm-content')
  // 导出交出去的是屏幕上这份 DOM：放大状态会跟着出去（纸上只剩图的一角），那排缩放按钮
  // 也会被一起画上去。序列化的这会儿还原视口、藏掉控件，完事立刻恢复（见 withDiagramZoomPaused）。
  return withDiagramZoomPaused(() => ({
    content,
    // 图片与 PDF 导出要的是「和屏幕上一模一样」，所以仍旧交编辑器那份 DOM；
    // HTML 导出交的是**一篇文档**：语义标签，没有编辑器自己的类名和行结构。
    html: editorRoot?.innerHTML ?? '',
    document: editorRoot ? documentHTMLFrom(editorRoot) : '',
    styles,
    bodyClass: Array.from(document.body.classList)
      .filter((name) => name !== 'show-file-panel' && name !== 'paper')
      .join(' '),
    background: getComputedStyle(document.body).backgroundColor,
  }))
}

async function exportCurrentHTML(): Promise<void> {
  const wasSourceMode = sourceModeActive
  const sourceScrollRatio = wasSourceMode ? scrollRatio(editorScroller()) : 0
  const content = getContent()

  // 导出拍的是渲染后的 DOM，所以先把源码模式切回来；缓冲区本来就是同一份，
  // 不需要再把文本塞回去。导出后回到用户原来的编辑模式。
  if (wasSourceMode) {
    exitSourceMode()
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => {
        requestAnimationFrame(() => resolve())
      })
    })
  }

  await withExportLayout(() => window.electronAPI.exportHTML(getExportSnapshot(content)))

  if (wasSourceMode) {
    enterSourceMode()
    restoreScrollRatio(editorScroller(), sourceScrollRatio)
  }
}

async function exportCurrentImage(preset: 'desktop' | 'mobile'): Promise<void> {
  const wasSourceMode = sourceModeActive
  const sourceScrollRatio = wasSourceMode ? scrollRatio(editorScroller()) : 0
  const content = getContent()

  if (wasSourceMode) {
    exitSourceMode()
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
    })
  }

  await withExportLayout(() => window.electronAPI.exportImage(getExportSnapshot(content), preset))

  if (wasSourceMode) {
    enterSourceMode()
    restoreScrollRatio(editorScroller(), sourceScrollRatio)
  }
}

// 导出幻灯片 PDF: the file and the dialog belong to the main process, so it
// asks the window to become paper through this hook. The deck's rule holds here
// too — pages come from the RENDERED document — so source mode is rendered
// first, or the export would print whatever was on screen before it was typed.
window.__colamdSlidesExport = {
  enter: async () => {
    if (sourceModeActive) {
      exitSourceMode()
      await new Promise<void>((resolve) => {
        requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
      })
    }
    return enterPrintLayout()
  },
  exit: () => exitPrintLayout()
}

// 导出 PDF 打印的是**这个窗口本身**（主进程直接 printToPDF），所以两件事都得在
// 打印前做完：当前行的源码、光标、选区不该上纸；而且必须先把整篇渲染出来，
// 否则纸上只有当前视口那一屏（长文档导出截断的根因）。主进程 await 这个钩子。
/**
 * 导出 HTML 的那份内容。
 *
 * 导出要弹系统保存框，无头环境点不了，所以把「会被写进文件的那段 HTML」单独露出来：
 * 验收脚本（scripts/verify-features.mjs）拿它检查语义标签。只读，不改任何状态。
 */
window.__colamdExportDocumentHTML = (): string => {
  const root = document.querySelector<HTMLElement>('#editor .cm-content')
  return root ? documentHTMLFrom(root) : ''
}

window.__colamdPrintExport = {
  enter: async () => {
    setCleanExport(true)
    await enterPaperLayout()
  },
  exit: () => {
    exitPaperLayout()
    setCleanExport(false)
  }
}

// 放映幻灯片: the pages are the editor's own blocks, so the document has to be
// rendered before the deck starts. 源码模式只是把渲染装饰收起来了，切回来就行，
// 缓冲区里一直是同一份文本。
async function toggleSlideshow(): Promise<void> {
  if (isPresenting()) {
    stopSlideshow()
    return
  }
  const wasSourceMode = sourceModeActive
  const sourceScrollRatio = wasSourceMode ? scrollRatio(editorScroller()) : 0

  if (wasSourceMode) {
    exitSourceMode()
    await new Promise<void>((resolve) => {
      requestAnimationFrame(() => requestAnimationFrame(() => resolve()))
    })
  }

  const started = startSlideshow({
    onStart: () => {
      setEditorEditable(false)
      void window.electronAPI.setSlideshowFullscreen(true)
    },
    onExit: () => {
      setEditorEditable(true)
      void window.electronAPI.setSlideshowFullscreen(false)
      if (wasSourceMode) {
        enterSourceMode()
        restoreScrollRatio(editorScroller(), sourceScrollRatio)
      }
    }
  })
  // Nothing to present (an empty document has no page): put the user back where
  // they were instead of leaving them in a mode that did not open.
  if (!started && wasSourceMode) {
    enterSourceMode()
    restoreScrollRatio(editorScroller(), sourceScrollRatio)
  }
}

async function init(): Promise<void> {
  const api = window.electronAPI
  // macOS keeps its own overlay scrollbars (drawn while you scroll, no layout
  // space, never in the way). The thin custom scrollbar is only for Windows and
  // Linux, where the platform default is a chunky always-on bar.
  if (!/^Mac/i.test(navigator.platform)) document.body.classList.add('platform-non-mac')
  // Windows has no traffic lights on the left and draws its window controls inside
  // the row on the right (titleBarOverlay), so it needs both ends of the row told
  // apart from macOS. The menu button shows there too, since the menu bar is
  // hidden (the Alt key still reveals the system one).
  if (/Windows/i.test(navigator.userAgent)) {
    document.body.classList.add('platform-win')
    document.getElementById('app-menu-btn')?.removeAttribute('hidden')
  }
  const language = await api.getLanguage()
  fileManagerName = await api.getFileManagerName()
  setUiLanguage(language)
  const savedTheme = loadSavedTheme()
  if (savedTheme.startsWith('custom:')) {
    // Load before applying: a newly opened window must not briefly paint the
    // custom class without its stylesheet. Missing files self-heal to elegant.
    const css = await api.loadThemeCSS(savedTheme.slice(7))
    applyTheme(css ? savedTheme : 'elegant', css ?? undefined)
  } else {
    applyTheme(savedTheme)
  }
  applyEditorFont(loadSavedEditorFont())

  const searchPanel = new SearchPanel()
  searchPanel.setLanguage(language)
  api.onSearch(() => searchPanel.show())
  // Cmd/Ctrl+F 在页面这一层也接一次：菜单的快捷键是主路径（macOS 上由菜单先接走），
  // 但菜单被隐藏或平台不转发快捷键时，这个兜底能保证打开的仍是**我们自己的**面板，
  // 而不是 CodeMirror 自带那块只有英文的（它已经从编辑器扩展里摘掉了）。
  // Cmd/Ctrl+/ 同理接源码切换（CodeMirror 的注释绑定已摘掉）。页面 preventDefault 之后
  // 菜单的同名快捷键不会再触发；切换不是幂等的，两边都触发就等于没按。
  document.addEventListener('keydown', (event) => {
    if (!(event.metaKey || event.ctrlKey) || event.shiftKey || event.altKey) return
    if (event.key === '/') {
      event.preventDefault()
      toggleSourceMode()
      return
    }
    if (event.key.toLowerCase() !== 'f') return
    event.preventDefault()
    searchPanel.show()
  })
  api.onStepFont((delta) => {
    if (delta === 0) resetEditorFontSize()
    else stepEditorFontSize(delta)
  })
  // ⌘+ / ⌘- / ⌘0 在页面这一层也接一次，理由和 ⌘F 那条一样：菜单是主路径，菜单被隐藏或
  // 平台不转发快捷键时，这一层能接住。这三项调的是正文字号，界面尺寸不动（见 font-settings）。
  document.addEventListener('keydown', (event) => {
    if (!(event.metaKey || event.ctrlKey) || event.altKey) return
    const key = event.key
    const delta = key === '+' || key === '=' ? 1 : key === '-' || key === '_' ? -1 : key === '0' ? 0 : null
    if (delta === null) return
    event.preventDefault()
    if (delta === 0) resetEditorFontSize()
    else stepEditorFontSize(delta)
  })
  api.onFormatCommand((id) => runFormatCommand(id as FormatCommandId))
  updateUiLanguage()

  await createEditor('editor', (markdown) => {
    updateWordCount(markdown)
  }, () => {
    if (!editorReady) return
    if (!applyingProgrammaticChange) setDirty()
    scheduleOutlineUpdate()
  })
  updateWordCount()
  editorReady = true
  resetDirty()

  // Main asks for an authoritative snapshot before any close or quit.
  api.onRequestDocumentState(async (requestId) => {
    captureActiveTab()
    // Report every tab that still has unsaved content. The main process writes
    // the ones with a path and refuses to close on the untitled ones, so a
    // background tab can never be dropped silently.
    window.electronAPI.respondDocumentState(requestId, {
      dirty,
      content: getFileContent(),
      tabs: tabs.filter((tab) => tab.dirty).map((tab) => ({ path: tab.filePath, content: tab.content }))
    })
  })
  // Report readiness only after every listener is registered — the main process
  // reacts to this signal by flushing queued tab-opens and by trusting the
  // window with close/quit flows. It sat mid-init once and the flush raced
  // bindTabBar: files handed over at launch were dropped silently.
  api.reportRendererReady()

  // Save before switching files. If saving is cancelled or fails, preserve the
  // current document rather than opening another file over it.
  fileListEl().addEventListener('click', async (e) => {
    const btn = (e.target as HTMLElement).closest('button[data-path]') as HTMLButtonElement | null
    if (!btn || !btn.dataset.path) return
    // A directory expands in place; the tree only ever grows downward.
    if (btn.dataset.kind === 'directory') {
      togglePanelDirectory(btn.dataset.path)
      return
    }
    if (btn.dataset.path === currentFilePath) return
    // ⌘/Ctrl click opens the file in a tab of its own (design.md).
    if (btn.dataset.kind === 'file' && (e.metaKey || e.ctrlKey)) {
      await openFileInNewTab(btn.dataset.path)
      return
    }
    if (btn.dataset.kind === 'file' && dirty && !await saveCurrent()) return
    await api.openSibling(btn.dataset.path)
  })

  fileToggleBtnEl().addEventListener('click', togglePanel)
  // Right-click on a file panel entry opens the native context menu. The
  // parent entry has no target worth acting on, so it keeps the default.
  fileListEl().addEventListener('contextmenu', (e) => {
    const btn = (e.target as HTMLElement).closest('button[data-path]') as HTMLButtonElement | null
    const path = btn?.dataset.path
    const kind = btn?.dataset.kind
    if (!path || kind === 'parent') return
    e.preventDefault()
    void api.showEntryContextMenu(path, kind === 'directory' ? 'directory' : 'file')
  })
  initPanelResize()
  bindTabBar(api)
  // The launch document (the welcome screen or a restored file) is a tab from
  // the first frame, so the strip never renders without one.
  ensureTab()
  renderTabBar()
  fileTabEl().addEventListener('click', () => setPanelMode('files'))
  outlineTabEl().addEventListener('click', () => setPanelMode('outline'))
  api.onToggleFilePanel(() => togglePanel())

  sourceToggleBtnEl().addEventListener('click', toggleSourceMode)
  api.onToggleSourceMode(() => toggleSourceMode())
  // The outline tracks scrolling in both modes so it doubles as a progress
  // view (#64); rAF keeps the rect reads to one batch per frame. `scrollend`
  // also releases the outline jump lock as soon as a jump scroll settles.
  // 两种模式共用一个编辑器，滚动都发生在 CM6 的 .cm-scroller 上。
  editorScroller().addEventListener('scroll', scheduleOutlineActiveSync, { passive: true })
  editorScroller().addEventListener('scrollend', endOutlineJump)
  // Anchor-link jumps start inside the editor; the phase signal engages the
  // same jump lock the outline clicks use, so the highlight cannot be stolen
  // by sections passed along the way (review on #68).
  onEditorJumpPhase((phase) => (phase === 'start' ? beginOutlineJump() : endOutlineJump()))

  api.onSiblingsChanged((files) => {
    // A watcher refresh can change any directory that is open, so drop the
    // cached levels and let the expanded ones read themselves again.
    panelChildren.clear()
    renderFileList(files)
  })
  updatePanelVisibility()
  // 文件列表只是面板内容，读失败不该打断后面保存、打开、导出等菜单动作的注册。
  // 之前这里 await，一旦列出目录卡住/报错，init 后半段全部不注册，表现就是
  // 「菜单点了没反应」。
  void refreshSiblings().catch((e) => reportRuntimeError('refreshSiblings', e))

  api.onMenuOpen(async () => {
    // 'file-opened' event drives the content load (and file-panel refresh)
    await api.openFile()
  })

  api.onMenuSave(() => { void saveCurrent() })
  api.onMenuSaveAs(() => { void saveCurrent(true) })
  api.onMenuExportPDF(() => api.exportPDF())
  api.onMenuExportHTML(() => { void exportCurrentHTML() })
  api.onMenuExportDOCX(async () => {
    // Diagrams are drawn again for the page rather than reused from the screen
    // (src/renderer/editor/mermaid-export.ts), so this awaits a render per
    // diagram before the save dialog opens.
    const style = readDocxStyle()
    // HTML 块先截成图片；之后的公式扫描基于替换过的文本，偏移量才不会错位。
    const html = await markdownWithHtmlImages(getContent(), `#${style.text}`)
    const math = await markdownWithMathImages(html.content, isChinese(), `#${style.text}`)
    const payload = await markdownForWord(math.content, isChinese(), diagramPrintPalette(style))
    await api.exportDOCX({
      content: payload.content,
      images: { ...html.images, ...math.images, ...payload.images },
      imageSizes: { ...html.sizes, ...math.sizes },
      style,
    })
  })
  api.onMenuExportImage((preset) => { void exportCurrentImage(preset) })
  api.onMenuPlaySlideshow(() => { void toggleSlideshow() })

  api.onNewFile(() => {
    exitSourceMode()
    ensureTab()
    applyContent('')
    scheduleOutlineUpdate()
    renderTabBar()
  })
  api.onFileOpened((data) => {
    // A document opened into a window that has none yet (a launch with a file)
    // lands in the first tab rather than creating a second one.
    ensureTab()
    currentFilePath = data.path
    applyDocumentFileUrl(data.fileUrl ?? null)
    dirty = false
    const tab = activeTab()
    if (tab) {
      tab.filePath = data.path
      tab.dirty = false
      tab.revision = documentRevision
      tab.diskContent = data.content
    }
    resetDirty()
    setContent(data.content, true)
    const resetScroll = () => {
      editorScroller().scrollTop = 0
    }
    resetScroll()
    requestAnimationFrame(resetScroll)
    updateFileTitle()
    updatePanelVisibility()
    refreshSiblings()
    scheduleOutlineUpdate()
    renderTabBar()
  })
  api.onFileChanged((content) => {
    if (dirty) {
      raiseExternalConflict()
      return
    }
    const body = takeFrontmatter(content)
    // An external write is not something the reader can undo into; making it
    // one undo step would also let a stray undo write stale content back.
    // 两种模式共用一个缓冲区，这条路与模式无关。
    setMarkdownProgrammatically(body, true)
    updateSourceToggle()
    updateWordCount()
    resetDirty()
    scheduleOutlineUpdate()
  })

  api.onSetTheme((theme) => applyTheme(theme))

  // The View menu's two choices land here. Nothing else follows the panel: the
  // side is a preference of the renderer's, like the panel's width.
  api.onSetPanelSide((side) => applyPanelSide(side))
  api.onSetPageWidth((width) => applyPageWidth(width))

  // macOS takes the traffic lights away in full screen, so the row drops the 96px
  // they sit in. The main process owns the window state and reports it here, both
  // on the transitions and once at startup for a window restored into full screen.
  api.onFullscreenChange((isFullscreen) => {
    document.body.classList.toggle('fullscreen', isFullscreen)
  })

  // The row's own menu button. Windows hides the menu bar (autoHideMenuBar) so the
  // shell is one row; this button pops the same native menu, which keeps the menu
  // itself identical on every platform.
  document.getElementById('app-menu-btn')?.addEventListener('click', () => void api.popupAppMenu())
  api.onLanguageChanged((language: UiLanguage) => {
    setUiLanguage(language)
    searchPanel.setLanguage(language)
    updateUiLanguage()
    // Tab labels and the close tooltip are built in the current language.
    renderTabBar()
  })
  api.onExternalConflictResult((result) => {
    if (result.action === 'load' && typeof result.content === 'string') {
      applyContent(result.content)
      resetDirty()
      updateWordCount()
      scheduleOutlineUpdate()
      if (typeof result.recoveryPath === 'string') showRecoveryHint(result.recoveryPath)
    } else {
      // Keep mine: resume autosave; the next save overwrites the external edit.
      showSaveStatus('dirty')
      if (dirty) scheduleAutosave()
    }
    externalConflictPending = false
  })
  api.onOpenFontSettings(() => showFontSettingsModal())
  api.onEditorFontChanged((prefs) => applyEditorFont(prefs.family || prefs.size ? prefs : null))
  api.onSetCustomCSS((css) => {
    const theme = loadSavedTheme()
    applyTheme(theme, css)
  })

  api.onMenuImportTheme(async () => {
    const result = await api.loadCustomTheme()
    if (result) applyTheme(`custom:${result.name}`, result.css)
  })

  // --- Auto update banner (weak, non-blocking) ---
  // 2.7.0 换了编辑器内核，用户点「更新」之前就该知道这次不是普通修复。
  // 只给需要提前打招呼的版本写一句，没登记的版本保持原样。
  const UPDATE_NOTES: Record<string, { zh: string; en: string }> = {
    '2.7.0': { zh: '这次换了编辑器内核', en: 'new editor core' },
    '2.7.1-beta.1': { zh: '选中一段不再翻成源码', en: 'selections stay rendered' },
    '2.7.3': { zh: '本地链接能跳了', en: 'local links navigate' }
  }
  let updateDownloaded = false
  function showUpdateBanner(version: string): void {
    const zh = isChinese()
    const note = UPDATE_NOTES[version]
    const suffix = note ? ` · ${zh ? note.zh : note.en}` : ''
    updateBannerTextEl().textContent = updateDownloaded
      ? (zh ? `新版本 v${version} 已就绪${suffix}` : `Update v${version} is ready${suffix}`)
      : (zh ? `发现新版本 v${version}${suffix}` : `Update v${version} available${suffix}`)
    updateBannerActionEl().textContent = updateDownloaded ? (zh ? '重启安装' : 'Restart') : (zh ? '更新' : 'Update')
    updateBannerActionEl().disabled = false
    updateBannerEl().hidden = false
  }

  api.onUpdateAvailable((version) => {
    updateDownloaded = false
    showUpdateBanner(version)
  })
  api.onUpdateDownloaded((version) => {
    updateDownloaded = true
    showUpdateBanner(version)
  })
  api.onUpdateProgress((percent) => {
    if (updateDownloaded) return
    updateBannerActionEl().textContent = isChinese() ? `下载中 ${percent}%` : `Downloading ${percent}%`
  })
  api.onUpdateError(() => {
    if (updateDownloaded) return
    updateBannerActionEl().textContent = isChinese() ? '下载失败，点击重试' : 'Failed, retry'
    updateBannerActionEl().disabled = false
  })

  updateBannerActionEl().addEventListener('click', async () => {
    if (updateDownloaded) {
      await api.installUpdate()
    } else {
      updateBannerActionEl().textContent = isChinese() ? '下载中…' : 'Downloading…'
      updateBannerActionEl().disabled = true
      try {
        await api.downloadUpdate()
      } catch {
        // The 'update-error' event may already have reset the label; this
        // catch covers the path where the IPC call itself rejects.
        updateBannerActionEl().textContent = isChinese() ? '下载失败，点击重试' : 'Failed, retry'
        updateBannerActionEl().disabled = false
      }
    }
  })
  document.getElementById('update-banner-dismiss')!.addEventListener('click', () => {
    updateBannerEl().hidden = true
  })

  document.addEventListener('dragover', (e) => e.preventDefault())
  document.addEventListener('drop', async (e) => {
    e.preventDefault()
    const file = e.dataTransfer?.files[0]
    if (!file) return
    const filePath = api.getPathForFile(file)
    if (!filePath) return
    const result = await api.openFilePath(filePath)
    // 'file-opened' event drives the content load when opened into this window
    void result
  })
}

// Errors after init leave no trace in a packaged app either. Same log, and the
// same error is written once per session so a render loop cannot fill the disk.
const reportedErrors = new Set<string>()
function reportRuntimeError(where: string, err: unknown): void {
  const text = err instanceof Error ? (err.stack ?? err.message) : String(err)
  const key = text.slice(0, 300)
  if (reportedErrors.has(key) || reportedErrors.size >= 50) return
  reportedErrors.add(key)
  console.error(`ColaMD ${where}:`, err)
  void window.electronAPI.logRendererError(`[${where}] ${text}`)
}
window.addEventListener('error', (event) => reportRuntimeError('error', event.error ?? event.message))
window.addEventListener('unhandledrejection', (event) => reportRuntimeError('unhandledrejection', event.reason))

// A packaged app has no console: without the IPC copy of this, a renderer that
// dies during init leaves nothing behind but a white window (#126).
init().catch((e) => {
  console.error('ColaMD init failed:', e)
  void window.electronAPI.logRendererError(e instanceof Error ? (e.stack ?? e.message) : String(e))
})
