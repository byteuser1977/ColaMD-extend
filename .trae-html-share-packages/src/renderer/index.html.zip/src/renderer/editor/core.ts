// 编辑器核心：源码缓冲区是唯一真相。
//
// 这个文件取代了原来的 milkdown/ProseMirror 核心。设计原则见
// docs/editor-architecture.md，一句话：**缓冲区里存的就是文件的字节，渲染是叠在
// 它上面的一层装饰。** 保存时把缓冲区原样写回，不做任何序列化。
//
// 由此得到一条可以在 CI 里断言的纪律：用户没改过的字节，保存时不变。
//
// 这一层需要 DOM（EditorView 要做布局测量）。不依赖 DOM 的那一半在 state.ts 里，
// 验收脚本直接消费那一半，所以保真的证明不需要真实浏览器。

import { Compartment, EditorState, RangeSet, type Extension } from '@codemirror/state'
import { EditorView, drawSelection, dropCursor, highlightSpecialChars, rectangularSelection, crosshairCursor, Decoration } from '@codemirror/view'
import { syntaxTree } from '@codemirror/language'
import { undo, redo } from '@codemirror/commands'
import { livePreview, livePreviewField, setEditorFocus, setMeasureHost } from './live-preview'
import { listInput } from './list-input'
import { searchHighlightField } from './search-highlight'
import { stateExtensions, editableCompartment, bodyStart } from './state'
import { editorTheme } from './source-theme'
import { cursorColors } from './cursor-colors'

export interface EditorOptions {
  /** 初始文本。就是文件的字节。 */
  doc?: string
  /** 文档变化时回调，参数是当前完整文本。 */
  onChange?: (markdown: string) => void
  /** 是否可编辑（放映幻灯片时会锁住）。 */
  editable?: boolean
}

/** 编辑器对外句柄。外壳只认这个，不认 CodeMirror。 */
export interface EditorHandle {
  /** 源码模式：关掉渲染装饰层，缓冲区只剩 markdown 语法高亮。 */
  setSourceMode(source: boolean): void
  /** 当前缓冲区内容，即文件应有的字节。 */
  getText(): string
  /** 用新文本替换整个文档（换文件、外部改动）。会清空撤销栈。 */
  setText(text: string, clearHistory?: boolean): void
  /** 把光标放到文档末尾的下一行（追加内容用）。 */
  appendText(text: string): void
  /** 聚焦。 */
  focus(): void
  /** 设置是否可编辑。 */
  setEditable(editable: boolean): void
  /** 撤销 / 重做。 */
  undo(): void
  redo(): void
  /** 拿到底层 view（装饰层、搜索面板需要）。 */
  getView(): EditorView
  /** 销毁。 */
  destroy(): void
}

let handle: EditorHandle | null = null

export function getEditorHandle(): EditorHandle | null {
  return handle
}

/**
 * 渲染装饰层的开关。源码模式就是把它换成空扩展：缓冲区不动，只是不再往上面画。
 * 模式跟着 EditorState 走（每个标签的状态各自记着），所以换状态不会丢模式。
 */
const livePreviewCompartment = new Compartment()

/**
 * 任务项的方框（`[ ]` / `[x]`）当作原子区间。
 *
 * 它被换成了一个 checkbox widget，但替换本身不拦光标：不声明的话光标能停在两个方框
 * 之间那一格里，看不见自己在哪，按左右键要一格一格试（#164）。声明成原子区间后，
 * 左右键一次跨过整个复选框。
 *
 * 范围从语法树上取，所以只覆盖眼下已经解析过的那一段；远处的任务项滚过去、被解析
 * 之后才变成原子，而光标本来也去不了没解析的地方，这个精度够用。
 */
const taskMarkerAtomicRanges = EditorView.atomicRanges.of((view) => {
  const doc = view.state.doc
  const ranges: { from: number; to: number }[] = []
  syntaxTree(view.state).iterate({
    enter: (node) => {
      if (node.name !== 'TaskMarker') return
      const line = doc.lineAt(node.from)
      // 行的前缀（`- ` / `* ` / `1. `）也算进来：光标停在 `-` 和 `[` 之间打字，
      // 列表标记就没了；停在 `]` 和正文之间打字，`[x]` 后面不再跟空格，任务语法也拆了。
      // 两种都是 `TaskMarker` 看着还在、下一帧就变回源码的那种怪事（#164）。
      const prefix = doc.sliceString(line.from, node.from)
      const quoteLen = /^(?:[ \t]*> ?)+/.exec(prefix)?.[0].length ?? 0
      const listPart = prefix.slice(quoteLen)
      const from = /^[ \t]*(?:[-*+]|\d+[.)])[ \t]+$/.test(listPart) ? line.from + quoteLen : node.from
      const trailing = doc.sliceString(node.to, Math.min(node.to + 1, line.to)) === ' ' ? node.to + 1 : node.to
      ranges.push({ from, to: trailing })
    },
  })
  // 这个值不参与绘制，只借 Range 的形状把位置报上去。
  return RangeSet.of(ranges.map((r) => ATOMIC_MARK.range(r.from, r.to)), true)
})

const ATOMIC_MARK = Decoration.replace({})

/** 这个状态是不是源码模式：装饰层的 field 在源码模式下不存在。 */
function isSourceMode(state: EditorState): boolean {
  return state.field(livePreviewField, false) === undefined
}

function editorExtensions(
  sourceMode: boolean,
  editable: boolean,
  onChange?: (markdown: string) => void,
): Extension {
  return [
    // 状态层：语言、高亮、撤销栈、缩进、快捷键（无 DOM，可进 harness）
    stateExtensions(),
    // 以下是 view 层：选区绘制、拖放光标、特殊字符、主题
    drawSelection(),
    cursorColors,
    // 自动换行。CodeMirror 默认**不换行**，长行会横向滚动；markdown 正文必须换行。
    EditorView.lineWrapping,
    dropCursor(),
    highlightSpecialChars(),
    rectangularSelection(),
    crosshairCursor(),
    editorTheme,
    // 装饰层：把源码画成所见即所得。它只画不写，所以装在这里不会影响
    // 「没改过的字节不许变」这条纪律。源码模式把它收起来，剩下的就是带 markdown
    // 语法高亮的原文（高亮在 state.ts 的 markdown 扩展里，跟模式无关）。
    livePreviewCompartment.of(sourceMode ? [] : livePreview),
    // 焦点变化要重算装饰：只有**正在编辑**的那一行才显示源码（见 live-preview 的 setEditorFocus）。
    // 用 DOM 事件而不是 EditorView.focusChangeEffect，是因为后者在创建时就已带焦点的编辑器上
    // 不会触发；下面创建完 view 之后补了一次初始值。
    EditorView.domEventHandlers({
      focus: (_event, view) => {
        if (view.dom.isConnected) view.dispatch({ effects: setEditorFocus.of(true) })
        return false
      },
      blur: (_event, view) => {
        if (view.dom.isConnected) view.dispatch({ effects: setEditorFocus.of(false) })
        return false
      },
    }),
    // 回车续列表。这是编辑器的输入手感，与渲染无关，所以单独一个模块。
    listInput,
    // 检索高亮。面板靠 effect 改它，而 effect 得有 StateField 接住；
    // 不装这一条，检索面板会以为高亮画上了，实际什么也没发生。
    searchHighlightField,
    // 任务项的复选框是一个 replace widget，但没声明成原子区间时，光标能停在
    // `[ ]` 两个方框之间那一格里：左右键要一格一格挪过去，停在里面打字又把
    // `- [ ]` 敲成 `- [x]` 之类的残骸（#164）。声明成原子区间后，光标一次跨过它。
    taskMarkerAtomicRanges,
    editableCompartment.of(EditorView.editable.of(editable)),
    // 文档变化的唯一出口：把新文本交给外壳
    EditorView.updateListener.of((update) => {
      if (update.docChanged && onChange) {
        onChange(update.state.doc.toString())
      }
    }),
  ]
}

export function createEditorCore(parent: HTMLElement, options: EditorOptions = {}): EditorHandle {
  const changeListener = options.onChange
  const editableAtStart = options.editable ?? true

  const view = new EditorView({
    state: EditorState.create({ doc: options.doc ?? '', extensions: editorExtensions(false, editableAtStart, changeListener) }),
    parent,
  })
  // 异步画完的图会改块高，widget 拿不到 view，由这里记一份（见 live-preview 的 remeasureAfterDraw）
  setMeasureHost(view)

  // 创建时就已经带焦点的编辑器不会触发 focus 事件（它一直是焦点），这里补一次初始值。
  // 不做这一步，用户一打开文件就打字，标记却不会显形。
  if (view.hasFocus) view.dispatch({ effects: setEditorFocus.of(true) })

  const api: EditorHandle = {
    getText: () => view.state.doc.toString(),

    setSourceMode(source: boolean): void {
      view.dispatch({ effects: livePreviewCompartment.reconfigure(source ? [] : livePreview) })
    },

    setText(text: string, clearHistory = false): void {
      if (view.state.doc.toString() === text) return
      // 换文件时必须把撤销栈清掉，否则撤销会跨文档串味。光标也要落到正文开头：
      // 属性区是收起来的，停在它里面敲出来的字会看不见（见 state.ts 的 bodyStart）。
      // 模式要跟着带过去：新状态从扩展表重建，不显式给 Compartment 值就会回到渲染模式，
      // 半兆以上的文档因此会先为整篇算一遍装饰。
      const next = clearHistory
        ? EditorState.create({
            doc: text,
            selection: { anchor: bodyStart(text) },
            extensions: editorExtensions(isSourceMode(view.state), editableAtStart, changeListener),
          })
        : view.state.update({ changes: { from: 0, to: view.state.doc.length, insert: text } }).state
      view.setState(next)
    },

    appendText(text: string): void {
      const end = view.state.doc.length
      const needsBreak = end > 0 && !view.state.doc.toString().endsWith('\n')
      view.dispatch({
        changes: { from: end, insert: (needsBreak ? '\n' : '') + text },
        selection: { anchor: end + (needsBreak ? 1 : 0) + text.length },
      })
      view.focus()
    },

    focus: () => view.focus(),
    setEditable(editable: boolean): void {
      view.dispatch({ effects: editableCompartment.reconfigure(EditorView.editable.of(editable)) })
    },
    undo: () => { undo(view) },
    redo: () => { redo(view) },
    getView: () => view,
    destroy(): void {
      setMeasureHost(null)
      view.destroy()
      handle = null
    },
  }

  handle = api
  return api
}
